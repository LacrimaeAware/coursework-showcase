Programming Concepts (Python)

Six complete course programs. Requires Python 3 and its standard library.

Open a terminal in the programs folder, then run a file, for example:
python city-queries.py

The database is one directory above the scripts, matching ../cities.db in the program. The golf program creates ../golf.txt when run.
